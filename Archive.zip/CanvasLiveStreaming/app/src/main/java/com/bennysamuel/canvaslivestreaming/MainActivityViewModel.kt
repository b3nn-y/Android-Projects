package com.bennysamuel.canvaslivestreaming

import androidx.compose.runtime.remember
import androidx.lifecycle.ViewModel

class MainActivityViewModel:ViewModel() {
    var correctword:String?=null
}