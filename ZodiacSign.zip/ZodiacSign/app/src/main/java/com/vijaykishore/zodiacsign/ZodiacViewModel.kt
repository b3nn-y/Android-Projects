package com.vijaykishore.zodiacsign

import androidx.lifecycle.ViewModel

class ZodiacViewModel: ViewModel() {
}